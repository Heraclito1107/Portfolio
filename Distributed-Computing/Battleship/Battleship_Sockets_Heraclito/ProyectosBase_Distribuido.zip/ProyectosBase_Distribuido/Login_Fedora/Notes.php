<?php
session_start();
$_SESSION['noteShown']=$_POST['dnote'];
//include "PageOne_Fedora.php";
header("Location: /Login_Fedora/PageOne_Fedora.php");
exit;
?>
