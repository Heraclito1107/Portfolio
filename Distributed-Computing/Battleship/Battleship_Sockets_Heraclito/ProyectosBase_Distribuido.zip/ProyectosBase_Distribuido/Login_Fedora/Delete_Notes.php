<?php
  session_start();
  $servername = "localhost";
  $username = "root";
  $password = "root";
  $dbname = "fedora";

  // Create connection
  $conn = new mysqli($servername, $username, $password,$dbname);

  // Check connection
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }
  $sql = "DELETE FROM notes WHERE note_name = '".$_POST['noteName']."'";
  mysqli_query($conn, $sql);
  unlink($_SESSION['userDir'].$_POST['noteName']);
  //include "PageOne_Fedora.php";
  header("Location: /Login_Fedora/PageOne_Fedora.php");
  exit;
?>
