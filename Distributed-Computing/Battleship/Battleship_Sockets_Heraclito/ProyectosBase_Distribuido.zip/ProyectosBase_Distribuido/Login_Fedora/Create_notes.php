<?php
session_start();
function saveNote()
{
  $user = $_SESSION['user'];
  $content = $_POST['noteArea'];
  $name = $_POST['noteName']; //.".txt";
  $note = fopen($_SESSION['userDir'].$name, "w");
  fwrite($note, $content);
  fclose($note);
  $servername = "localhost";
  $username = "root";
  $password = "root";
  $dbname = "fedora";

  // Create connection
  $conn = new mysqli($servername, $username, $password,$dbname);

  // Check connection
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }
  $sql = "SELECT user_id FROM users WHERE username = '".$user."'";
  $userid = mysqli_fetch_assoc(mysqli_query($conn, $sql));
  $sql2 = "SELECT note_id FROM notes WHERE note_name = '".$name."' AND author = '".$userid['user_id']."'";
  if(mysqli_num_rows(mysqli_query($conn, $sql2))==0)
  {
    $sql3 = "INSERT INTO notes(note_name, author) VALUES ('".$name."', '".$userid['user_id']."')";
    mysqli_query($conn, $sql3);
  }

  //include "PageOne_Fedora.php";
}
saveNote();
header("Location: /Login_Fedora/PageOne_Fedora.php");
exit;
?>
