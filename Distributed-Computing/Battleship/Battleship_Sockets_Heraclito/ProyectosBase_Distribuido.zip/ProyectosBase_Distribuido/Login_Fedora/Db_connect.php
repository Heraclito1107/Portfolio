<?php
	session_start();
	function conectarABaseDatosMySQLi(){
		$servername = "localhost";
		$username = "root";
		$password = "root";
		$dbname = "fedora";

		// Create connection
		$conn = new mysqli($servername, $username, $password,$dbname);

		// Check connection
		if ($conn->connect_error) {
		    die("Connection failed: " . $conn->connect_error);
		}
		$sql = "SELECT  * FROM users WHERE username = '".$_POST["user"]."' AND password = '".$_POST["pswd"]."'";
		$result = mysqli_query($conn,$sql);

		if (mysqli_num_rows($result) === 1) {

				$_SESSION['user'] = $_POST['user'];
				$_SESSION['userDir'] = __DIR__.'/Users/'.$_POST['user'].'/';
				$a =mysqli_fetch_assoc($result);
				$_SESSION['userType'] = $a['admin'];
				if($a['admin'])
				{
					//include "Admin_Page.php";
					header("Location: /Login_Fedora/Admin_Page.php");
					exit;
				}
				else {
					//include "PageOne_Fedora.php";
					header("Location: /Login_Fedora/PageOne_Fedora.php");
					exit;
				}
		}else{
			include "Login_Fedora.html";
			echo "<div align='center' style='color:white'>
				<p>Invalid username/password</p>
			</div>";
		}

	}
	conectarABaseDatosMySQLi();


 ?>
