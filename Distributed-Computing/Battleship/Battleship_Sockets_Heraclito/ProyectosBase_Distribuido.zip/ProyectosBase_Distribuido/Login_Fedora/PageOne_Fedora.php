<?php
  if (session_status() == PHP_SESSION_NONE) {
      session_start();
  }
  $servername = "localhost";
  $username = "root";
  $password = "root";
  $dbname = "fedora";
  $user = $_SESSION['user'];
  // Create connection
  $conn = new mysqli($servername, $username, $password,$dbname);
  // Check connection
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }

  $sql = "SELECT note_name from notes where author =(select user_id FROM users WHERE username = '".$user."')";
  $sql2 = "SELECT * FROM users where username = '".$user."'";
  $result = mysqli_query($conn,$sql);
  $userData = mysqli_query($conn, $sql2);
  mysqli_close($conn);
 ?>
<!DOCTYPE html>
<html lang="es-la" dir="ltr">
  <head>
    <link href="LoginStyle.css" rel="stylesheet" type="text/css">
    <meta charset="utf-8">
    <script type="text/javascript" src="CalcScript.js">
    </script>
    <script src="jquery-3.3.1.min.js"></script>
    <title>Desktop</title>
  </head>
  <script>
    function noteHint(str)
    {
      $('#notes').children().hide();
     var xmlhttp = new XMLHttpRequest();
           xmlhttp.onreadystatechange = function() {
               if (this.readyState == 4 && this.status == 200) {
                   document.getElementById("notes").innerHTML = this.responseText;
               }
           };
           xmlhttp.open("GET", "Note_search.php?q=" + str, true);
           xmlhttp.send();
    }
  </script>
  <body>
    <div>
      <button class="cmnElement" onclick ="displayCalc()">Calculator</button>
      <button class="cmnElement" id="npBtn" onclick="displayNP()">Notepad</button>
      <button class="cmnElement"  onclick ="displayFileExplorer()">File Explorer</button>
      <button class="cmnElement"  onclick ="displayEditProfile()">Edit profile</button>
      <button class="cmnElement" onclick ="displayInfo()">Developers info</button>

    </div>
    <div class="box" id="calculator" style="display:none">
      <div class="winHeader" align="right">
        <button onclick="hideCalc()" type="button" name="close" class="cmnElement windowBtn"> X </button>
      </div>
      <input type="text" name="calcInput" id="cDisplay" class="cmnElement" disabled="true">
      <div class="row">
        <button onclick="clearDisp()" type="button" name="button" class="cmnElement calcBtnElement">C</button>
        <button onclick="addElement('%')" type="button" name="button" class="cmnElement calcBtnElement">%</button>
        <button onclick="addElement('/')" type="button" name="button" class="cmnElement calcBtnElement">/</button>
      </div>
      <div class="row">
        <button onclick="addElement(7)" type="button" name="button" class="cmnElement calcBtnElement">7</button>
        <button onclick="addElement(8)" type="button" name="button" class="cmnElement calcBtnElement">8</button>
        <button onclick="addElement(9)" type="button" name="button" class="cmnElement calcBtnElement">9</button>
        <button onclick="addElement('*')" type="button" name="button" class="cmnElement calcBtnElement">*</button>
      </div>
      <div class="row">
        <button onclick="addElement(4)" type="button" name="button" class="cmnElement calcBtnElement">4</button>
        <button onclick="addElement(5)" type="button" name="button" class="cmnElement calcBtnElement">5</button>
        <button onclick="addElement(6)" type="button" name="button" class="cmnElement calcBtnElement">6</button>
        <button onclick="addElement('-')" type="button" name="button" class="cmnElement calcBtnElement">-</button>
      </div>
      <div class="row">
        <button onclick="addElement(1)" type="button" name="button" class="cmnElement calcBtnElement">1</button>
        <button onclick="addElement(2)" type="button" name="button" class="cmnElement calcBtnElement">2</button>
        <button onclick="addElement(3)" type="button" name="button" class="cmnElement calcBtnElement">3</button>
        <button onclick="addElement('+')" type="button" name="button" class="cmnElement calcBtnElement">+</button>
      </div>
      <div class="row">
        <button onclick="addElement(0)" type="button" name="button" class="cmnElement calcBtnElement">0</button>
        <button onclick="addElement('.')" type="button" name="button" class="cmnElement calcBtnElement">.</button>
        <button onclick="result()" type="button" name="button" class="cmnElement calcBtnElement">=</button>
      </div>
    </div>
    <div class="box" align="center" id="infoBox" style="display:none">
      <div class="winHeader" align="right">
        <button onclick="hideInfo()" type="button" name="close" class="cmnElement windowBtn"> X </button>
      </div>
      <div style="margin-bottom:20px">
        <div style="width:100px; display:flex; height:100px">
          <img src="logoUP.png" alt="Universidad Panamericana">
        </div>
      </div>
        <h1>Universidad Panamericana</h1>
        <h2>Campus Guadalajara</h2>
        <br>
        <h3>Desarrollo de aplicaciones web</h3>
        <br>
        <h3>Proyecto Final <br> <b>Sistema operativo basado en Web: <br> <u>Fedora</u> </b> </h3>
        <br>
        <h3>Profesor:<br> Dr. Juan Carlos López Pimentel</h3>
        <br>
        <h3>Alumnos</h3>
        <h3>Daniel Heráclito Pérez Díaz<br>Mariana Ramírez Cervantes</h3>
    </div>
		<?php
		if (isset($_SESSION['noteShown']))
		{
      $openNote = $_SESSION['noteShown'];
      $fAddress =$_SESSION['userDir'].$openNote;
      $noteS = fopen($fAddress, "r");
      $content = fread($noteS, filesize($fAddress));
      echo "<div class='box' id='notepad' style='display:block'>
				<form method='post'>
				<div class='winHeader' align='right'>
					<input type='text' class='note' name='noteName' value='".$_SESSION['noteShown']."'>
					<button formaction='Create_notes.php' type='submit' name='save' value='Save' class='cmnElement windowBtn'>Save</button>
          <button formaction='Delete_notes.php' type='submit' name='delete' value='Delete' class='cmnElement windowBtn'>Delete</button>
					<button onclick='hideNP()' type='button' name='close' class='cmnElement windowBtn'> X </button>
				</div>
				<div>
					<textarea class='note' rows='20' name='noteArea'>".$content."</textarea>
				</div>
			</form>
			</div>";
      unset($_SESSION['noteShown']);
		}
		else{
			echo "<div class='box' id='notepad' style='display:none'>
				<form action='Create_notes.php' method='post'>
				<div class='winHeader' align='right'>
					<input type='text' class='note' name='noteName' placeholder='File name...'>
					<input type='submit' name='save' value='Save' class='cmnElement windowBtn'>
					<button onclick='hideNP()' type='button' name='close' class='cmnElement windowBtn'> X </button>
				</div>
				<div>
					<textarea class='note' rows='20' name='noteArea'></textarea>
				</div>
			</form>
			</div>";
		}
		  ?>
    <div class="box" id="fileExplorer" style="display:none">
      <div class="winHeader" align="right">
        <button onclick="hideFileExplorer()" type="button" name="close" class="cmnElement windowBtn"> X </button>
      </div>
      <div>
        <input type="text" class="cmnElement" name="noteSearch" onkeyup="noteHint(this.value)" placeholder="Search...">
      </div>
      <div display="flex" id="notes">
				<?php
					while ($row = mysqli_fetch_assoc($result))
					{
						echo "<form action='Notes.php' method='post' id= '".$row['note_name']."'class='box fileIcon' style='display:inline-block'>
            <div align='center' style='overflow:hidden'>
            <button type='submit'>
            <input name='dnote' style='height:1px;width:1px;display:none' value = '".$row['note_name']."'>
            <img src='Logotxt.png' height='42' width='42'>
            </button>
            <p>".$row['note_name']."</p>
            </div>
            </form>";
					}
				?>
      </div>
	  </div>

		<div class="box" align="center" id="editProfile" style="display:none">
      <div class="winHeader" align="right">
          <button onclick="hideEditProfile()" type="button" name="close" class="cmnElement windowBtn"> X </button>
      </div>
      <form action='Update_user_info.php' method='post'>
      <?php
        $data = mysqli_fetch_assoc($userData);

        echo "Username:<input type='text' class='cmnElement idElement' name='username' style='text-align:center' value='".$data['username']."' > <br></br>
          Password:<input type='text' class='cmnElement idElement' name='password' style='text-align:center' value='".$data['password']."'><br></br>
          Name:<input type='text' class='cmnElement idElement' name='name' style='text-align:center' value='".$data['name']."'> <br></br>
          Lastname:<input type='text' class='cmnElement idElement' name='lastname' style='text-align:center' value='".$data['lastname']."'> <br></br>
          Phone:<input type='text' class='cmnElement idElement' name='phone' style='text-align:center' value='".$data['phone']."'> <br></br>
          City:<input type='text' class='cmnElement idElement' name='city' style='text-align:center' value='".$data['city']."'> <br></br>
          Address:<input type='text' class='cmnElement idElement' name='address' style='text-align:center' value='".$data['address']."'> <br></br>
          Birthdate:<input type='text' class='cmnElement idElement'name='birthdate' style='text-align:center' value='".$data['birthdate']."'> <br></br>
          <input type='submit' class='cmnElement idElement' name='updateInfo' value='Save changes'style='width:200px; height:40px'><br></br>"
          ?>
          </form>
    </div>

    <form>
      <div style="padding:10px">
        <button type="submit" name="button" formaction="Login_Fedora.html" id="cancelBtn" style="left:20px; bottom:40px">Return to Login</button>
      </div>
    </form>
  </body>
</html>
