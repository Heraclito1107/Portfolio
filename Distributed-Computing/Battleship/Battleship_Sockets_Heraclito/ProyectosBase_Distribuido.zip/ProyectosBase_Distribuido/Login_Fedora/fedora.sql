create database fedora;
use fedora;
create table users(
    user_id int auto_increment,
    username varchar(30),
    password varchar(30),
    admin bool,
    name varchar(30),
    lastname varchar(30),
    phone int (8),
    city varchar(30),
    address varchar(30),
    birthdate date,
    PRIMARY KEY (user_id)
); 
create table notes(
    note_id int auto_increment,
    note_name varchar(30) ,
    author int,
    PRIMARY KEY (note_id),
    CONSTRAINT author FOREIGN KEY (author)
    REFERENCES users(user_id)
); 

INSERT INTO `users`(`username`, `password`, `admin`, `name`, `lastname`, `phone`, `city`, `address`, `birthdate`) 
VALUES ('Mariana','mariana1',TRUE,'Mariana ','Ramirez Cervantes',36414221,'Guadalajara','Av.Guadalupe 34','1998-05-02'),
('0196539','mariana2',FALSE,'Guadalupe','Cervantes Ramirez',33916803,'Puebla','Calle Romero 2900','1997-02-05'),
('Daniel','daniel1',TRUE,'Daniel','Perez Diaz',36209980,'Saltillo','Av.Espina 12','1996-11-09'),
('0190575','daniel2',FALSE,'Heraclito','Diaz Perez',33206452,'Zapopan','Calle Bosques 6789','1997-07-12');

#INSERT INTO `notes`(`note_name`,`author`) VALUES('Recetas',1),('Listas',2),('Calculos',3),('Investigación',4);

