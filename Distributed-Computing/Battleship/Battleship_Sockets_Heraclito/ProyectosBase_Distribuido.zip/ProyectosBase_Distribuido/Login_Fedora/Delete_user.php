<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "fedora";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "DELETE FROM users WHERE username = '".$_POST['delUser']."'";

if(mysqli_query($conn, $sql) != FALSE)
{
  rmdir(__DIR__."/Users/".$_POST['delUser']);
  header("Location: /Login_Fedora/Admin_Page.php");
  exit;
}
 ?>
