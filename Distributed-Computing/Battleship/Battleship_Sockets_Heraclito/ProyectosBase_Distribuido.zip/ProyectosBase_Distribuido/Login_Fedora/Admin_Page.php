<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
  $servername = "localhost";
  $username = "root";
  $password = "root";
  $dbname = "fedora";
  $user = $_SESSION['user'];
  // Create connection
  $conn = new mysqli($servername, $username, $password,$dbname);
  // Check connection
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }

  $sql = "SELECT username from users ";
  $sql2 = "SELECT * FROM users where username = '".$user."'";
  $result = mysqli_query($conn,$sql);
  $result2 = mysqli_query($conn,$sql);
  $userData = mysqli_query($conn, $sql2);
	mysqli_close($conn);
 ?>
<!DOCTYPE html>
<html lang="es-la" dir="ltr">
  <head>
    <link href="LoginStyle.css" rel="stylesheet" type="text/css">
    <meta charset="utf-8">
    <script type="text/javascript" src="CalcScript.js">
    </script>
    <script src="jquery-3.3.1.min.js"></script>
    <title>Desktop</title>
  </head>
  <body>
    <div>
      <button class="cmnElement" onclick ="displayInfo()">Info</button>
      <button class="cmnElement" onclick ="displayUserList()">User List</button>
      <button class="cmnElement" onclick ="displayAddUser()">Add user</button>
      <button class="cmnElement" onclick ="displayDeleteUser()">Delete user</button>
      <button class="cmnElement" onclick ="displayEditProfile()">Edit profile</button>
    </div>

    <div class="box" align="center" id="userList" style="display:none">
      <div class="winHeader" align="right">
          <button onclick="hideUserList()" type="button" name="close" class="cmnElement windowBtn"> X </button>
      </div>
      <?php
      while ($row = mysqli_fetch_assoc($result))
      {
        echo "
        <div id = userPhoto style='margin-left:20px; display:inline-block; width:100px'>
        <p style='margin-top: 120px;'>".$row['username']."</p>
        </div>
        ";
      }
       ?>
    </div>
    <div class="box" align="center" id="addUser" style="display:none;padding-bottom:30px">
      <div class="winHeader" align="right">
          <button onclick="hideAddUser()" type="button" name="close" class="cmnElement windowBtn"> X </button>
      </div>
      <form action="Create_user.php" method="post">
        Username:   <input type="text" class='cmnElement idElement' name="username" > <br></br>
        Password:   <input type="text" class='cmnElement idElement' name="password" ><br></br>
        Admin:  <input type="checkbox" class='cmnElement idElement' name="admin" value = "1"><br></br>
        Name:   <input type="text" class='cmnElement idElement' name="name" > <br></br>
        Lastname:   <input type="text" class='cmnElement idElement' name="lastname" > <br></br>
        Phone:   <input type="text" class='cmnElement idElement' name="phone" > <br></br>
        City:   <input type="text" class='cmnElement idElement' name="city" > <br></br>
        Address:   <input type="text" class='cmnElement idElement' name="address" > <br></br>
        Birthdate:   <input type="text" class='cmnElement idElement' name="birthdate" > <br></br>
        <input type='submit' class='cmnElement idElement' name='updateInfo' value='Save changes'style='width:200px; height:40px'><br></br>
      </form>
    </div>
    <div class="box" align="center" id="deleteUser" style="display:none">
      <div class="winHeader" align="right">
          <button onclick="hideDeleteUser()" type="button" name="close" class="cmnElement windowBtn"> X </button>
      </div>
      <?php
      while ($row2 = mysqli_fetch_assoc($result2))
      {
        if($row2['username'] != $_SESSION['user'])
        {
          echo "
          <div id = userPhoto style='margin-left:20px; display:inline-block; width:100px'>
          <form action='Delete_user.php' method='post'>
          <button type='submit' class='cmnElement windowBtn' value= '".$row2['username']."' name='delUser' style='margin-top: 120px;'>".$row2['username']."</button>
          </form>
          </div>";
        }
      }
       ?>
    </div>
    <div class="box" align="center" id="infoBox" style="display:none">
      <div class="winHeader" align="right">
        <button onclick="hideInfo()" type="button" name="close" class="cmnElement windowBtn"> X </button>
      </div>
      <div style="margin-bottom:20px">
        <div style="width:100px; display:flex; height:100px">
          <img src="logoUP.png" alt="Universidad Panamericana">
        </div>
      </div>

        <h1>Universidad Panamericana</h1>
        <h2>Campus Guadalajara</h2>
        <br><br>
        <h3>Desarrollo de aplicaciones web</h3>
        <br>
        <h3>Práctica: <i>Login</i> </h3>
        <br>
        <h3>Profesor:</h3>
        <h3>Dr. Juan Carlos López Pimentel</h3>
        <br>
        <h3>Alumno:</h3>
        <h3>Daniel Heráclito Pérez Díaz 0190575<br>Mariana Ramírez Cervantes 0196539</h3>
    </div>
    <div class="box" align="center" id="editProfile" style="display:none">
      <div class="winHeader" align="right">
          <button onclick="hideEditProfile()" type="button" name="close" class="cmnElement windowBtn"> X </button>
      </div>
      <form action='Update_user_info.php' method='post'>
      <?php
        $data = mysqli_fetch_assoc($userData);

        echo "Username:<input type='text' class='cmnElement idElement' name='username' style='text-align:center' value='".$data['username']."' > <br></br>
          Password:<input type='text' class='cmnElement idElement' name='password' style='text-align:center' value='".$data['password']."'><br></br>
          Name:<input type='text' class='cmnElement idElement' name='name' style='text-align:center' value='".$data['name']."'> <br></br>
          Lastname:<input type='text' class='cmnElement idElement' name='lastname' style='text-align:center' value='".$data['lastname']."'> <br></br>
          Phone:<input type='text' class='cmnElement idElement' name='phone' style='text-align:center' value='".$data['phone']."'> <br></br>
          City:<input type='text' class='cmnElement idElement' name='city' style='text-align:center' value='".$data['city']."'> <br></br>
          Address:<input type='text' class='cmnElement idElement' name='address' style='text-align:center' value='".$data['address']."'> <br></br>
          Birthdate:<input type='text' class='cmnElement idElement'name='birthdate' style='text-align:center' value='".$data['birthdate']."'> <br></br>
          <input type='submit' class='cmnElement idElement' name='updateInfo' value='Save changes'style='width:200px; height:40px'><br></br>"
          ?>
          </form>
    </div>
    <form>
      <div style="padding:10px">
        <button type="submit" name="button" formaction="Login_Fedora.html" id="cancelBtn" style="left:20px; bottom:40px">Return to Login</button>
      </div>
  </form>
  </body>
</html>
