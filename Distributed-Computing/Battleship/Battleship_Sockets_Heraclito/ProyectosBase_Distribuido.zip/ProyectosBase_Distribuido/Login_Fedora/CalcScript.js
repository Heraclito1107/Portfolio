function displayCalc()
{
  var calc = document.getElementById("calculator");
  if (calc.style.display === "none") {
        calc.style.display = "block";
    }
  hideNP();
  hideInfo();
  hideFileExplorer();
  hideEditProfile();
  }

function hideCalc()
{
  var calc = document.getElementById("calculator");
  if (calc.style.display != "none") {
        calc.style.display = "none";
    }
  clearDisp();
}

function displayInfo()
{
  var info = document.getElementById("infoBox");
  if (info.style.display == "none") {
        info.style.display = "block";
    }
  hideNP();
  hideCalc();
  hideFileExplorer();
  hideEditProfile();
  }

function hideInfo()
{
  var info = document.getElementById("infoBox");
  if (info.style.display != "none") {
        info.style.display = "none";
    }
}
function displayFileExplorer()
{
  var fileExplorer = document.getElementById("fileExplorer");
  if (fileExplorer.style.display == "none") {
        fileExplorer.style.display = "block";
    }
  hideNP();
  hideCalc();
  hideInfo();
  hideEditProfile();
  var btn = document.getElementById("sbmt");
  btn.submit();
  }

function hideFileExplorer()
{
  var fileExplorer = document.getElementById("fileExplorer");
  if (fileExplorer.style.display != "none") {
        fileExplorer.style.display = "none";
    }
}

function displayUserList()
{
  var userList = document.getElementById("userList");
  if (userList.style.display == "none") {
        userList.style.display = "block";
    }
  hideInfo();
  hideAddUser();
  hideDeleteUser();
  hideEditProfile();
  var btn = document.getElementById("sbmt");
  btn.submit();
  }

function hideUserList()
{
  var userList = document.getElementById("userList");
  if (userList.style.display != "none") {
        userList.style.display = "none";
    }
}

function displayAddUser()
{
  var addUser = document.getElementById("addUser");
  if (addUser.style.display == "none") {
        addUser.style.display = "block";
    }
  hideInfo();
  hideUserList();
  hideDeleteUser();
  hideEditProfile();
  var btn = document.getElementById("sbmt");
  btn.submit();
  }

function hideAddUser()
{
  var addUser = document.getElementById("addUser");
  if (addUser.style.display != "none") {
        addUser.style.display = "none";
    }
}
function displayEditProfile()
{
  var editProfile = document.getElementById("editProfile");
  if (editProfile.style.display == "none")
  {
        editProfile.style.display = "block";
  }
  hideNP();
  hideInfo();
  hideFileExplorer();
  hideCalc();
  hideInfo();
  hideUserList();
  hideDeleteUser();
  hideAddUser();
  var btn = document.getElementById("sbmt");
  btn.submit();
  }

function hideEditProfile()
{
  var editProfile = document.getElementById("editProfile");
  if (editProfile.style.display != "none") {
        editProfile.style.display = "none";
    }
}
function displayDeleteUser()
{
  var deleteUser = document.getElementById("deleteUser");
  if (deleteUser.style.display == "none") {
        deleteUser.style.display = "block";
    }
  hideInfo();
  hideUserList();
  hideAddUser();
  hideEditProfile();
  var btn = document.getElementById("sbmt");
  btn.submit();
  }

function hideDeleteUser()
{
  var deleteUser = document.getElementById("deleteUser");
  if (deleteUser.style.display != "none") {
        deleteUser.style.display = "none";
    }
}

function addElement(e)
{
  var disp = document.getElementById("cDisplay");
  disp.value += e;
}

function clearDisp()
{
  var disp = document.getElementById("cDisplay");
  disp.value = "";
}

function result()
{
  var disp = document.getElementById("cDisplay");
  if(eval(disp.value) != undefined)
    {
      disp.value = eval(disp.value);
    }
}

function displayNP()
{
  var nPad = document.getElementById("notepad");
  if (nPad.style.display === "none") {
        nPad.style.display = "block";
    }
  hideCalc();
  hideInfo();
  hideFileExplorer();
  hideEditProfile();
}

function hideNP()
{
  var nPad = document.getElementById("notepad");
  if (nPad.style.display != "none") {
        nPad.style.display = "none";
    }
}

function editNote($noteName){
  $('#fileExplorer').append("<?php $_SESSION['noteShown'] = " + $noteName +"?>");
  document.getElementById("notepad");
}

function erase(element){
  $(element).remove();
}
