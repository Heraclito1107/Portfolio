<?php
	session_start();
	$servername = "localhost";
  $username = "root";
  $password = "root";
  $dbname = "fedora";

  // Create connection
  $conn = new mysqli($servername, $username, $password,$dbname);

  // Check connection
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }

	$isAdmin = 0;
	if(isset($_POST['admin']))
	{
		$isAdmin = 1;
	}
	$sql = "INSERT INTO users (username, password, admin, name, lastname, phone, city, address, birthdate)
								VALUES ('".$_POST['username']."',
									 					 '".$_POST['password']."',
														 '".$isAdmin."',
														 '".$_POST['name']."',
														 '".$_POST['lastname']."',
                             '".$_POST['phone']."',
                             '".$_POST['city']."',
                             '".$_POST['address']."',
                             '".$_POST['birthdate']."')";

	if(mysqli_query($conn, $sql) != FALSE)
	{
		mkDir(__DIR__."/Users/".$_POST['username']);
	  header("Location: /Login_Fedora/Admin_Page.php");
	  exit;
	}
 ?>
