function startTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    var tag = "AM";
    if ((h>12))
    {
      h=h%12;
      tag = "PM"
    }
    h = checkTime(h);
    m = checkTime(m);
    document.getElementById('hour').innerHTML = h + ":" + m + " " + tag;
    var t = setTimeout(startTime, 500);
    var y = today.getFullYear();
    var mo = today.getMonth();
    var d = today.getDate();
    var weekday = new Array();
    weekday[0] = "Sunday";
    weekday[1] = "Monday";
    weekday[2] = "Tuesday";
    weekday[3] = "Wednesday";
    weekday[4] = "Thursday";
    weekday[5] = "Friday";
    weekday[6] = "Saturday";
    var sDay = weekday[today.getUTCDay()];
    var month = new Array();
    month[0] = "January";
    month[1] = "February";
    month[2] = "March";
    month[3] = "April";
    month[4] = "May";
    month[5] = "June";
    month[6] = "July";
    month[7] = "August";
    month[8] = "September";
    month[9] = "October";
    month[10] = "November";
    month[11] = "December";
    var sMonth = month[mo];


    document.getElementById("date").innerHTML = sDay + ", " + sMonth + " " + d + ", " + y;
}
function checkTime(i) {
    if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
    return i;
}
