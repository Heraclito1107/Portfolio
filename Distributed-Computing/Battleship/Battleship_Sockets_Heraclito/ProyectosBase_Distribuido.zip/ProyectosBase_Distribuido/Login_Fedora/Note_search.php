<?php
session_start();
$q = $_REQUEST['q'];
$servername = "localhost";
$username = "root";
$password = "Miad2018";
$dbname = "fedora";
$user = $_SESSION['user'];
// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT note_name from notes where author =(select user_id FROM users WHERE username = '".$user."') AND (note_name like '".$q."%')";
$result = mysqli_query($conn,$sql);
while ($row = mysqli_fetch_assoc($result))
{
  echo "<form action='Notes.php' method='post' id= '".$row['note_name']."'class='box fileIcon' style='display:inline-block'>
  <div align='center' style='overflow:hidden'>
  <button type='submit'>
  <input name='dnote' style='height:1px;width:1px;display:none' value = '".$row['note_name']."'>
  <img src='Logotxt.png' height='42' width='42'>
  </button>
  <p>".$row['note_name']."</p>
  </div>
  </form>";
}

 ?>
