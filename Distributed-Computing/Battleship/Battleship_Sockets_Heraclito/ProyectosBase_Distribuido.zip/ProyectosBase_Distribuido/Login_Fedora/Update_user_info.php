<?php
  session_start();
  $servername = "localhost";
  $username = "root";
  $password = "root";
  $dbname = "fedora";

  // Create connection
  $conn = new mysqli($servername, $username, $password,$dbname);

  // Check connection
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }

  $sql = "UPDATE users SET username = '".$_POST['username']."',
                           password = '".$_POST['password']."',
                           name = '".$_POST['name']."',
                           lastname = '".$_POST['lastname']."',
                           phone = '".$_POST['phone']."',
                           city = '".$_POST['city']."',
                           address = '".$_POST['address']."',
                           birthdate = '".$_POST['birthdate']."'
                           WHERE username = '".$_SESSION['user']."'";
  if(mysqli_query($conn, $sql) != FALSE)
  {

    if(rename(__DIR__."/Users/".$_SESSION['user'], __DIR__."/Users/".$_POST['username']))
    {
      $_SESSION['userDir'] = __DIR__."/Users/".$_POST['username'].'/';
      $_SESSION['user'] = $_POST['username'];
    }
  }
  if($_SESSION['userType'])
  {
    header("Location: /Login_Fedora/Admin_Page.php");
  }
  else {
      header("Location: /Login_Fedora/PageOne_Fedora.php");
    }
  exit;
 ?>
