/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalserver_oscarheraclito;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import static finalserver_oscarheraclito.FinalServer_OscarHeraclito.registeredUsers;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
/**
 *
 * @author Heraclito
 */
public class UserThread implements Runnable{
    public String name;
    public Boolean online;
    public Socket socket;
    public DataInputStream inSocket;
    public DataOutputStream outSocket;
    List<Project> myProjects;
    List<Project> sharedWithMe;

    public UserThread(Socket socket, DataInputStream inSocket, DataOutputStream outSocket) {
        this.socket = socket;
        this.inSocket = inSocket;
        this.outSocket = outSocket;
        this.online = true;
        this.myProjects = Collections.synchronizedList(new ArrayList<Project>());
        this.sharedWithMe = Collections.synchronizedList(new ArrayList<Project>());
        
    }

    @Override
    public void run() {
        File personalDir = new File("Users/" + name);
        personalDir.mkdirs();
        try {
            
            while(true)
            {
                int code = inSocket.readInt();
                System.out.println(code);
                selectAction(code);
                if(code == 110)
                    break;
            }
            inSocket.close();
            outSocket.close();
            socket.close();
        } catch (IOException ex) {
           Logger.getLogger(UserThread.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    private void selectAction(int action) throws IOException
    {
        switch(action)
        {
            case 101: //Nueva conexión
            {
                outSocket.writeInt(registeredUsers.size());
                for(int i = 0; i < registeredUsers.size(); i++)
                    outSocket.writeUTF(registeredUsers.get(i).name);

                for (UserThread registeredUser : registeredUsers) {
                    if(!registeredUser.equals(this) && registeredUser.online)
                    {
                        registeredUser.outSocket.writeInt(10);
                        registeredUser.outSocket.writeUTF(name);
                    }
                }
                break;
            }
            case 102: //Crear proyecto
            {
                String projectName = inSocket.readUTF();
                myProjects.add(new Project(this, projectName));
                break;
            }
            case 103: //Compilar proyecto
            {
                Project p = findProject(inSocket.readUTF());
                String result = p.compileProject();
                outSocket.writeInt(11);
                outSocket.writeUTF(p.name);
                outSocket.writeUTF(result);
                break;
            }
            case 104: //Reingreso
            {
                online = true;
                outSocket.writeInt(registeredUsers.size());
                for(int i = 0; i < registeredUsers.size(); i++)
                    outSocket.writeUTF(registeredUsers.get(i).name);
                
                outSocket.writeInt(myProjects.size());
                for(int i = 0; i < myProjects.size(); i++)
                {
                    outSocket.writeUTF(myProjects.get(i).name);
                    outSocket.writeUTF(myProjects.get(i).content);
                    outSocket.writeInt(myProjects.get(i).sharedWith.size());
                    for(int j = 0; j < myProjects.get(i).sharedWith.size(); j++)
                        outSocket.writeUTF(myProjects.get(i).sharedWith.get(j).name);
                }

                outSocket.writeInt(sharedWithMe.size());
                for(int i = 0; i < sharedWithMe.size(); i++)
                {
                    outSocket.writeUTF(sharedWithMe.get(i).name);
                    outSocket.writeUTF(sharedWithMe.get(i).content);
                    outSocket.writeInt(sharedWithMe.get(i).sharedWith.size());
                    for(int j = 0; j < sharedWithMe.get(i).sharedWith.size(); j++)
                        outSocket.writeUTF(sharedWithMe.get(i).sharedWith.get(j).name);
                }
                break;
            }
            case 105: //Compartir proyecto con usuario
            {
                Project p = findProject(inSocket.readUTF());
                UserThread user = findUser(inSocket.readUTF());
                p.shareWithUser(user);
                user.outSocket.writeInt(12);
                user.outSocket.writeUTF(p.name);
                user.outSocket.writeUTF(p.content);
                for(int i = 0; i < p.sharedWith.size(); i++)
                {
                    user.outSocket.writeUTF(p.sharedWith.get(i).name);
                    if(!p.sharedWith.get(i).equals(user))
                    {
                        try {
                            p.sharedWith.get(i).outSocket.writeInt(16);
                            p.sharedWith.get(i).outSocket.writeUTF(p.name);
                            p.sharedWith.get(i).outSocket.writeUTF(user.name);
                        } catch (IOException ex) {
                            Logger.getLogger(UserThread.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
                break;
            }
            case 106: //Eliminar proyecto
            {
                Project p = findProject(inSocket.readUTF());
                for(UserThread sharing: p.sharedWith)
                {
                    if(!sharing.equals(this))
                    {
                        sharing.outSocket.writeInt(13);
                        sharing.outSocket.writeUTF(p.name);
                    }
                }
                p.deleteFile();
                myProjects.remove(p);
                break;
            }
            case 107: //Mensaje
            {
                Project p = findProject(inSocket.readUTF());
                if(p != null)
                    p.sendMessage(inSocket.readUTF(), this);
                break;
            }
            case 108: //Dejar de compartir con usuario
            {
                Project p = findProject(inSocket.readUTF());
                UserThread user = findUser(inSocket.readUTF());
                p.stopSharing(user);
                user.outSocket.writeInt(17);
                user.outSocket.writeUTF(p.name);
                for(UserThread sharing: p.sharedWith)
                {
                    sharing.outSocket.writeInt(15);
                    sharing.outSocket.writeUTF(p.name);
                    sharing.outSocket.writeUTF(user.name);
                }
                break;
            }
            case 109: //Guardar proyecto
            {
                Project p = findProject(inSocket.readUTF());
                int rows = inSocket.readInt();
                String cont = "";
                for(int i = 0; i < rows; i++)
                {
                    cont += inSocket.readUTF() +"\n"; 
                }
                System.out.println("Yey");
                p.content = cont;
                p.saveProjectFile();
                break;
            }
            case 110: //Actualizar proyecto
            {
                Project p = findProject(inSocket.readUTF());
                int rows = inSocket.readInt();
                String cont = "";
                for(int i = 0; i < rows; i++)
                {
                    cont += inSocket.readUTF(); 
                            if(i < rows-1)
                                cont+="\n"; 
                }
                p.content = cont;
                //p.updateContent();
                for(int i = 1; i < p.sharedWith.size(); i++)
        {
            if(!p.sharedWith.get(i).equals(p.owner))
            {
                try {
                    p.sharedWith.get(i).outSocket.writeInt(18);
                    p.sharedWith.get(i).outSocket.writeUTF(p.name);
                    String[] cont2 = p.content.split("\n");
                    p.sharedWith.get(i).outSocket.writeInt(cont2.length);
                    for(int j = 0; j < cont2.length; j++)
                    {
                        p.sharedWith.get(i).outSocket.writeUTF(cont2[j]);
                    }
                    
                } catch (IOException ex) {
                    Logger.getLogger(UserThread.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
                break;
            }
            case 111: //Desconexión
            {
                online = false;
                for(Project p: myProjects)
                {
                    p.saveProjectFile();
                }
                break;
            }
        }
    }
    
    private Project findProject(String projectName)
    {
        for(int i = 0; i < myProjects.size(); i++)
        {
            if(myProjects.get(i).name.equals(projectName))
                return myProjects.get(i);
        }
        return null;
    }
    
    private UserThread findUser(String userName)
    {
        for(int i = 0; i < registeredUsers.size(); i++)
        {
            if(registeredUsers.get(i).name.equals(userName))
                return registeredUsers.get(i);
        }
        return null;
    }
}
