/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalserver_oscarheraclito;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author Heraclito
 */
public class FinalServer_OscarHeraclito {

    public static List<UserThread> registeredUsers;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        ServerSocket server = new ServerSocket(5000);
        registeredUsers = Collections.synchronizedList(new ArrayList<UserThread>());
        File usersDir = new File("Users");
        usersDir.mkdirs();
        while(true)
        {
            Socket ss = null;
            try {
                if(!server.isClosed())
                {
                    ss = server.accept();
                    UserThread current  = new UserThread(ss, new DataInputStream(ss.getInputStream()), new DataOutputStream(ss.getOutputStream()));
                    String name = current.inSocket.readUTF();
                    System.out.println(name);
                    UserThread oldUser = findUser(name);
                    if(oldUser == null)
                    {
                        current.name = name;
                        registeredUsers.add(current);
                        Thread t = new Thread(current);
                        //Thread t = new Thread(new UserThread(ss, new DataInputStream(ss.getInputStream()), new DataOutputStream(ss.getOutputStream())));
                        t.start();
                    }
                    else
                    {
                        oldUser.socket = current.socket;
                        oldUser.inSocket = current.inSocket;
                        oldUser.outSocket = current.outSocket;
                    }
                }
                else
                    break;
                
            } catch (IOException ex) {
            }
        }
    }
    private static UserThread findUser(String userName)
    {
        for(int i = 0; i < registeredUsers.size(); i++)
        {
            if(registeredUsers.get(i).name.equals(userName))
                return registeredUsers.get(i);
        }
        return null;
    }
}

