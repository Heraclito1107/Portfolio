/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalserver_oscarheraclito;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Heraclito
 */
public class Project {
    public String name;
    public String content;
    UserThread owner;
    List<UserThread> sharedWith;

    public Project(UserThread owner, String name) {
        this.name = name;
        this.owner = owner;
        sharedWith = Collections.synchronizedList(new ArrayList<UserThread>());
        sharedWith.add(owner);
    }
    
    public void sendMessage(String mess, UserThread author)
    {
        for(int i = 0; i < sharedWith.size(); i++)
        {
            if(!sharedWith.get(i).equals(author))
            {
                try {
                    sharedWith.get(i).outSocket.writeInt(14);
                    sharedWith.get(i).outSocket.writeUTF(name);
                    sharedWith.get(i).outSocket.writeUTF(author.name + ": " +mess);
                } catch (IOException ex) {
                    Logger.getLogger(UserThread.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
    public void shareWithUser(UserThread user)
    {
        sharedWith.add(user);
    }
    
    public void stopSharing(UserThread user)
    {
        sharedWith.remove(user);
    }
    
    public Boolean haveAccess(UserThread user)
    {
        if(sharedWith.contains(user))
            return true;
        return false;                   
    }
    
    public void updateContent()
    {
        System.out.println("Size:" + sharedWith.size());
        for(int i = 1; i < sharedWith.size(); i++)
        {
            if(!sharedWith.get(i).equals(owner))
            {
                try {
                    sharedWith.get(i).outSocket.writeInt(18);
                    sharedWith.get(i).outSocket.writeUTF(name);
                    sharedWith.get(i).outSocket.writeUTF(content);
                } catch (IOException ex) {
                    Logger.getLogger(UserThread.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
    public void loadContent()
    {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("Users/" + owner.name + "/" + name));
            content = "";
            String line = "";
            while ((line = reader.readLine()) != null) {
                content += (line + "\n");
            }
            reader.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Project.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Project.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void saveProjectFile()
    {
        try {
            PrintWriter writer = new PrintWriter(new FileWriter("Users/" + owner.name + "/" + name));
            writer.append(content);
            writer.close();
        } catch (IOException ex) {
            Logger.getLogger(Project.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public String compileProject()
    {
        saveProjectFile();
        String outText = "";
        try
        {
            ProcessBuilder builder = new ProcessBuilder("cmd.exe", "/c", "g++ Users/" + owner.name + "/" + name);// 2> result.txt");
            builder.redirectErrorStream(true);
            Process p = builder.start();
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while (true) {
                line = r.readLine();
                if (line == null)
                    break;
                outText += line + "\n";
            }
        System.out.println(outText);
        }
        catch (IOException e)
        {
            // Excepciones si hay algún problema al arrancar el ejecutable o al leer su salida.*/
            System.err.println("Error en el método exec()");
        }
        if(outText.equals(""))
            outText = "File succesfully compiled!";
        return outText;
    }
    
    public void deleteFile()
    {
        File file = new File("Users/" + owner.name + "/" + name);
        file.delete();
    }
}
